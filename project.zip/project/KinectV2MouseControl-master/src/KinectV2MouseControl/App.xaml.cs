﻿using System.Windows;

namespace KinectV2MouseControl
{
    public partial class App : Application
    {
    }
}
