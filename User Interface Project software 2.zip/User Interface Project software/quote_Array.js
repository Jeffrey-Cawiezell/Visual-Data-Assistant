function bible(){
var bible = new array(“&quot;The Lord is my strength and my song, 
	and he has become my salvation; this is my God, 
	and I will praise him, my father God, and I will
	exalt him. &quot; - Exodus 15:2”, “&quot;But they 
	who wait for the Lord shall renew their strength; 
	they shall mount up with wings like eagles; they shall 
	run and not be weary; they shall walk and not faint. 
	&quot; - Isaiah 40:31“, “ &quot;Therefore encourage one another and build each other up, just as 
	in fact you are doing&quot; - 1 Thessalonians 5:11“, “&quot;For I know the plans I have for you, declares the Lord, 
	plans to prosper you and not to harm you, plans to give you hope and a future&quot; - Jeremiah 29:11”, “:&quot;Casting all your anxieties on him, 
	because he cares for you. &quot; - 1 Peter 5:7”, “&quot;Cast your burden on the LORD, and he will sustain you; he will never permit the righteous to 
	be moved. &quot; - Psalm 55:22”, “&quot;I have set the LORD always before me; because he is at my right hand, I shall not be shaken. &quot; - Psalm 16:8”, 
	“&quot;Trust in the LORD with all your heart, and do not lean on your own understanding. In all your ways acknowledge him, and he will make 
	straight your paths. &quot; - Proverbs 3:5-6”, “ &quot;Have I not commanded you? Be strong and courageous. Do not be frightened, and do not be dismayed, 
	or the LORD your God is with you wherever you go. &quot; - Joshua 1:9”, “&quot;The steadfast love of the LORD never ceases; his mercies never come to an 
	end; they are new every morning; great is your faithfulness. &quot; - Lamentations 3:22-23”);

var bibleQuote = bible[Math.floor(Math.random()*bible.length)];
document.writeln('quote') + bible[bibleQuote];
}