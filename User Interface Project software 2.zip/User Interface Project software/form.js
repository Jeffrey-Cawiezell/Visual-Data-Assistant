"use strict";

$(document).ready(function(){
  //var showForm = function(evt){
    /*var name = $("#name").val();
    var description = $("#description").val();
    var quote = $("#quote").val();
    var gems = $("#gems").val();
    var isValid = true;*/
  //results.style.display = "block";
  	var displayTasks = function(tasks) {
        if ( tasks === undefined ) {
            tasks = getSortedTasksArray();
        }
        var taskString = tasks.reduce( function( prev, current ) {
            return prev + current[0] + "\n";
        }, ""); // pass initial value for prev parameter

        // display tasks string and set focus on task text box
        $(".grey_rectangle").val( taskString );
        $("#name").focus();
        //$(".grey_rectangle").val(localStorage.E15tasks);
        //var tasks = localStorage.getItem("E15tasks");
        //document.getElementById(".grey_rectangle").innerHTML = tasks;
    };
        var getSortedTasksArray = function() {
        var tasks = [];
        var taskString = localStorage.E16tasks || "";
        
        if (taskString.length > 0) {
            // split string on first delimiter. Then, loop array, split
            // strings on second delimiter, and store array in tasks array
            var interim = taskString.split( "|" );
            for (var i = 0; i < interim.length - 1; i++) {
                tasks.push( interim[i].split( "~~" ));
            }
            
            // sort array of arrays by due date
            tasks.sort(function(arr1, arr2) {
                var a = new Date(arr1[1]); // 2nd element of first array
                var b = new Date(arr2[1]); // 2nd element of second array

                if ( a < b ) { return -1; }
                else if ( a > b ) { return 1; }
                else { return 0; }
            });
        }
        return tasks;
    };
    
/*  $("#plus").click(function(){
    if(document.getElementById("#to-do_Form").style.display == "none"){
      document.getElementById("#to-do_Form").style.display = "block";
    }
    else{
      document.getElementById("#to-do_Form").style.display = "none"; 
    }
  });*/
  //email javascript to edit for form
  $( "#submission" ).click(function(evt) {
    $("span").text("");
    var name = $("#name").val();
    var dueDate = $("#due_date").val();
    var quote = $("#quote").val();
    var gems = $("#gems").val();
    var isValid = true;
    // validate the first entry
    if (name === "") { 
      $("#name").next().text("This field is required.");
      isValid = false;
    }
    else{
                  // add task to web storage 
            var tasks = localStorage.E15tasks || "";  // default value of empty string
            var newTask = [name, dueDate];
            //localStorage.E15tasks = tasks.concat( name, "\n" );
            localStorage.E16tasks = tasks + newTask.join( "~~" ) + "|";
            // clear task text box and re-display tasks
            //$(".grey_rectangle").val( "" );
           	$("#name").val( "" );
            $("#due_date").val("");
            displayTasks();
    
    }
    // validate the second entry
    if (dueDate === "") { 
      $("#due_date").next().text("This field is required.");
      isValid = false;
    }
    
    // validate the third entry  
    if ($("#quote").value === "") {
      $("#quote").next().text("This field is required.");
      isValid = false;
    }

    // submit the form if all entries are valid
    if (isValid) {
      $("#to-do_Item").submit();
      displayTasks();
    }
    else{
      evt.preventDefault();
    }
  });

    displayTasks();
});

function showForm() {
      var x = document.getElementById('to-do_Form');
      if (x.style.display === 'none') {
        x.style.display = 'block';
      } else {
        x.style.display = 'none';
      }
    }